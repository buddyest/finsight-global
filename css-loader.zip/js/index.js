// A CSS Loader based on gif (https://imgur.com/iWGr9AP)

// A pen by @Vestride